import { NextPage } from 'next'
import Map from '@components/MapVanilla'
import useStaticLocation, { PermissionType } from '@hooks/useStaticLocation'
import { Box } from '@chakra-ui/layout'
import { useEffect, useState } from 'react'

const MapPage: NextPage = () => {
  const [user_coords, permission] = useStaticLocation()

  const [driver_coords, setDriverCoords] = useState({
    lat: 18.5927365,
    lng: 73.7910521,
  })

  const hospital_coords = {
    lat: 18.657153,
    lng: 73.734649,
  }

  useEffect(() => {
    const set = () => {
      setDriverCoords({
        lat: driver_coords.lat,
        lng: driver_coords.lng + 0.001,
      })

      console.log('Changed Driver Location')
    }

    setInterval(set, 2000)
  }, [])

  if (permission !== PermissionType.GRANTED)
    return <Box>Getting Permission...</Box>

  return (
    <>
      <Map
        user_coords={user_coords}
        hospital_coords={hospital_coords}
        driver_coords={driver_coords}
      />
    </>
  )
}

export default MapPage
