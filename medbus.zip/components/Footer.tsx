import { Box } from '@chakra-ui/layout'

const Footer = () => {
  return <Box></Box>
}

export default Footer
